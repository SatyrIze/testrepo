// Get the add recommendation form
const addRecommendationForm = document.getElementById("add-recommendation");

// Add an event listener to the form
addRecommendationForm.addEventListener("submit", (e) => {
  // Prevent the default action of the form
  e.preventDefault();

  // Get the input field
  const input = document.querySelector("#add-recommendation input");

  // Get the value of the input field
  const value = input.value;

  // Create a new recommendation
  const recommendation = document.createElement("li");
  recommendation.innerHTML = `
    <div>
      <p>${value}</p>
    </div>
  `;

  // Add the recommendation to the recommendations list
  const recommendationsList = document.getElementById("recommendations-list");
  recommendationsList.appendChild(recommendation);

  // Clear the input field
  input.value = "";

  // Get the dialog element
  const dialog = document.getElementById("my-dialog");

  // Open the dialog
  dialog.showModal();

  // Get the dialog content element
  const dialogContent = document.querySelector("#my-dialog div");

  // Create a new paragraph element to display the countdown
  const countdown = document.createElement("p");
  countdown.innerHTML = "Closing in... 3";
  countdown.style.textAlign = "center";

  // Add the countdown to the dialog content
  dialogContent.appendChild(countdown);

  // Start the countdown
  let seconds = 3;
  const interval = setInterval(() => {
    seconds--;
    countdown.innerHTML = `Closing in... ${seconds}`;

    if (seconds === 0) {
      // Close the dialog
      dialog.close();

      // Clear the interval
      clearInterval(interval);
      // Remove the countdown from the dialog content
      dialogContent.removeChild(countdown);
    }
  }, 1000);
});
